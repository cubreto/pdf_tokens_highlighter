require(shiny)
require(shinydashboard)

## NOTE THIS SHOULD BE CHANGED TO BE APP SPECIFIC FOLDER !!
APP_WWW_DIR ='D:/programming/r/app_highlighter/www/'
PYTHON_SCRIPT_PATH = paste0(APP_WWW_DIR, 'python_text_highlighter_v2.py') ## needed for Python, 0th argument

# Define UI ----
ui <- fluidPage(
  titlePanel("token highlighter"),
  
  sidebarLayout(
    sidebarPanel("control panell",
                 #fileInput("tokens", "Select file with tokens",
                 #          multiple = FALSE,
                 #           accept = c(".pdf")),
                 #fileInput("textPdf", "Select file with text to highlight",
                 #           multiple = FALSE,
                 #           accept = c(".pdf"))),
                 actionButton('tokens', 'Select file with tokens'),
                 actionButton('textPdf', 'Select file with text')),
    mainPanel(
      htmlOutput('pdfviewer')
      )
  )
)

# Define server logic ----
server <- function(input, output) {
  
  tokens_path = reactive({
    return(input$tokens)
  })
  
  text_path = reactive({
    return(input$textPdf)
  })
  
  output$pdfviewer = renderText({
    ## TO DO: explore if shinys inputFile can give real path to the PDF
    ## by design it uses a temporary path (so it blocks read from python)
    ## I used a workaround that is ugly but works
    
    ## whathappens here is: 
    ## R expects to find the PDF with highlights in the R app's www directory.
    ## R calls python script to create the PDF
    ## 
    ## R app should be called from the browser otherwise it won't render PDF correctly
    ## In addition to that, application specific paths should be defined, like the path to www
    
    
    #tokens_path = input$tokens$name ## needed for python, 1st argument
    #text_path = input$textPdf$name ## needed for python, 2nd argument
    tokens_path = gsub("\\\\", "/", file.choose()) ## needed for python, 1st argument, alternative version with action button
    text_path = gsub("\\\\", "/", file.choose()) ## needed for python, 2nd argument, alternative version with action button
    
    if(!is.na(tokens_path) & ! is.na(text_path)){
      highlighed_file_path = gsub(pattern = '.pdf', replacement='_highlighted.pdf', x=basename(text_path)) ## needed for R
      save_path = paste0(APP_WWW_DIR, highlighed_file_path) ## needed for python 3rd argument
      
      command = paste('python',
                       PYTHON_SCRIPT_PATH,
                       tokens_path,
                       text_path,
                       save_path)
      
      print(command)
      print(highlighed_file_path)
      
      system(command)
      
      return(
        paste(
          '<iframe style="height:600px; width:100%" src="', highlighed_file_path, '"></iframe>', sep = ""))
    }
    return('')
      
    })
}

# Run the app ----
shinyApp(ui = ui, server = server)
