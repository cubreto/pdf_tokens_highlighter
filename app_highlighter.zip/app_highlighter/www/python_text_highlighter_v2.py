
# coding: utf-8

# In[3]:


import fitz
import sys


# In[4]:


MAX_TOKEN_OCCURENCES = 100


# In[ ]:


def clean_tokens(tokens):
    '''
    NOTE: This function needs to be re-written to extract the tokens from the document given its format
    Right now it assumes that the first line is a redundant header and that each token is in a new line
    
    IN:
    tokens (list) - list of tokens from the pdf
    
    OUT
    tokens (list) - list of cleaned and unique tokens from the pdf
    '''
    
    ## the assumption is that each token is in a new line, so split by new line character
    tokens = [page_text.split('\n') for page_text in tokens]
    
    ## if the file with tokens is multi-page, flatten the list
    if len(tokens) > 1:
        tokens = [elem for sublist in tokens for elem in sublist]
    
    ## the below most likely needs to be re-written to match the case
    tokens = tokens[1:]
    tokens = set(tokens)
    tokens = [t for t in tokens if len(t) != 0]
    
    return tokens


# In[ ]:


def main():
    ## get files locations from command line run by R
    FILE_WITH_TOKENS = sys.argv[1]
    FILE_TO_SCAN = sys.argv[2]
    PATH_TO_SAVE = sys.argv[3]
    
    ## open pdf
    tokensDoc = fitz.open(FILE_WITH_TOKENS) 
    scanDoc = fitz.open(FILE_TO_SCAN) 
    
    ## read in all text from the file with tokens
    tokens = []
    for page_number in range(tokensDoc.pageCount):
        tokens.append(tokensDoc.getPageText(page_number))
    tokensDoc.close()

    tokens = clean_tokens(tokens)
    
    ## the below will store all tokens positions on all pages in format: {page : {token : [position]}}
    ## this is mainly for further use in developing the code
    ## token_positions = {} 

    ## highlight all tokens in each page
    for page_number in range(scanDoc.pageCount):
        page_positions = dict()
        for token in tokens:
            # get positions and add highlights
            rectangles = scanDoc.searchPageFor(page_number, token, hit_max=MAX_TOKEN_OCCURENCES)
            for r in rectangles:
                scanDoc[page_number].addHighlightAnnot(r)
            ## page_positions[token] = rectangles ## this may be removed if no further use of tokens and positions is needed
        ## token_positions[page_number] = page_positions ## this may be removed if no further use of tokens and positions is needed

    ## save a new pdf with highlights and close the file
    ## NOTE, save has an  argument 'incremental' that overwrites the current pdf (i.e. adds highlight to existing pdf)
    scanDoc.save(PATH_TO_SAVE)
    scanDoc.close()


# In[ ]:


if __name__ == '__main__':
    main()

